const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
   
    cb(null, file.originalname); 
  }
});

// 2. استخدام إعدادات التخزين الجديدة
const upload = multer({ storage: storage });
const session = require('express-session');
const http = require('http');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const app = express();
const db = new sqlite3.Database('./db/app.db');
const serveIndex = require('serve-index');
const path = require('path');
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', serveIndex('uploads'), express.static('uploads'));
app.use('/public', express.static('public'));
app.use(cookieParser()); // <-- أضيفي هذا السطر

// ...
app.use(session({
  secret: 'insecure-demo-secret',
  resave: false,
  saveUninitialized: true,
  cookie: {
    httpOnly: false  
  }
}));
// Middleware لتعيين متغيرات افتراضية للقوالب
app.use((req, res, next) => {
  res.locals.title = 'Vulnerable Lab'; // هذا هو العنوان الافتراضي
  res.locals.user = req.session.user || null; // هذا يغني عن إرسال المستخدم في كل مرة
  next();
});

// ensure DB file exists by running init.sql if empty
const fs = require('fs');
if (!fs.existsSync('./db/app.db') || fs.statSync('./db/app.db').size === 0) {
  console.log('Note: Please initialize the DB using sqlite3 or run the provided init script manually.');
}

// Home: lists comments (stored XSS possible)
app.get('/', (req, res) => {
  db.all('SELECT comments.id, comments.body, users.username FROM comments JOIN users ON users.id = comments.user_id', [], (err, rows) => {
    if (err) return res.send('DB error');
    // NOTE: outputting body directly into template without encoding -> Stored XSS
    res.render('index', { comments: rows, user: req.session.user });
  });
});

// Register
// Register
app.get('/register', (req, res) => res.render('register', { message: '' }));
app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const cleanUsername = username; 
  const passwordHash = crypto.createHash('md5').update(password).digest('hex');
  db.run(`INSERT INTO users (username, password, role) VALUES ('${username}','${passwordHash}','user')`, function(err){
    if (err) return res.render('register', { message: 'Error or user exists' });
    res.redirect('/login');
  });
});

// Login 
// Login 
app.get('/login', (req, res) => res.render('login', { message: '' }));
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const cleanUsername = username.trim();
  const passwordHash = crypto.createHash('md5').update(password).digest('hex');
  const q = `SELECT * FROM users WHERE username = '${username}' AND password = '${passwordHash}'`;
  db.get(q, [], (err, row) => {
    if (err) return res.send('DB error');
   if (row) {
      req.session.user = { id: row.id, username: row.username, role: row.role };
      res.cookie('user_role', row.role); 
      res.redirect('/dashboard');
    } else {
      res.render('login', { message: 'Invalid' });
    }
  });
});
  
app.get('/logout', (req, res) => { req.session.destroy(()=>res.redirect('/')); });

// Dashboard
app.get('/dashboard', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  db.get('SELECT COUNT(*) AS cnt FROM comments', [], (err, row) => {
    const stats = { comments: row ? row.cnt : 0 };
    res.render('dashboard', { user: req.session.user, stats });
  });
});

// Profile (insecure editable fields)
app.get('/profile', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  res.render('profile', { user: req.session.user, message: '' });
});
app.post('/profile', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const display = req.body.display || '';
  // no sanitization, stored in session only for demo
  req.session.user.display = display;
  res.render('profile', { user: req.session.user, message: 'Updated (in session only)' });
});

// Comment posting (Stored XSS + Injection)
app.post('/comment', (req, res) => {
  const body = req.body.body || '';
  const userId = req.session.user ? req.session.user.id : 1; // default to alice
  // intentionally vulnerable: direct insertion
  db.run(`INSERT INTO comments (user_id, body) VALUES (${userId}, '${body.replace("'","\'")}')`, function(err) {
    if (err) return res.send('DB error');
    res.redirect('/');
  });
});

// View single comment
app.get('/comment/:id', (req, res) => {
  const id = req.params.id;
  db.get(`SELECT comments.id, comments.body, users.username FROM comments JOIN users ON users.id = comments.user_id WHERE comments.id = ${id}`, [], (err, row) => {
    if (err || !row) return res.send('Not found');
    res.render('comment', { comment: row, user: req.session.user });
  });
});

// Admin users list (Broken access control example)
app.get('/users', (req, res) => {
  // intentionally weak: only checks role value in session
  //  <--  تم تغيير التحقق ليقرأ من الكوكيز الضعيفة
  if (!req.cookies.user_role || req.cookies.user_role !== 'admin') {
    return res.send('Access denied - Now try editing your cookie!');
  }
  db.all('SELECT id, username, role FROM users', [], (err, rows) => {
    res.render('users', { users: rows, user: req.session.user });
  });
});

// Insecure file upload (Security Misconfiguration)
app.post('/upload', upload.single('file'), (req, res) => {
  // no type checking, no size checking
  res.send('File uploaded to uploads/' + req.file.filename);
});

// SSRF example: server fetches given URL
app.get('/fetch', (req, res) => {
  const target = req.query.url;
  if (!target) return res.send('Provide ?url=');
  // no validation -> SSRF vulnerable
  http.get(target, (r) => {
    let data = '';
    r.on('data', c => data += c);
    r.on('end', () => res.send(`<pre>${data.slice(0,200)}</pre>`));
  }).on('error', e => res.send('Error fetching'));
});

// Insecure configuration info leak
app.get('/config', (req, res) => {
  res.render('admin-panel'); 
});
app.get('/config/download-users', (req, res) => {
  db.all('SELECT username, password FROM users', [], (err, rows) => {
    if (err) {
      return res.status(500).send('Error fetching user data.');
    }
    let csvContent = 'username,password_md5_hash\n';
    rows.forEach(row => {
      csvContent += `${row.username},${row.password}\n`;
    });
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="user_credentials_export.csv"');
    res.send(csvContent);
  });
});
app.get('/download', (req, res) => {
  res.send('Pretend this is a downloaded binary that was tampered');
});

// اجعل السيرفر يستمع لكل الواجهات
app.listen(3000, '0.0.0.0', () => console.log('Server running on port 3000'));

