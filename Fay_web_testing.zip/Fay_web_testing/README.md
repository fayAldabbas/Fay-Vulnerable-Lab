# Vulnerable Lab - OWASP Top 10 (Enhanced UI)

IMPORTANT: Run only locally in an isolated environment (VM or local machine) and do NOT expose to the Internet.

## Quick start (Windows + VS Code)
1. Open the folder in VS Code.
2. Open Terminal (use cmd.exe if PowerShell execution policy blocks npm).
3. Run `npm install`.
4. Initialize DB (optional but recommended):
   - Install sqlite3 CLI and run: `sqlite3 db\\app.db < db\\init.sql`
   - OR skip and insert rows via UI/register.
5. Run `node app.js`.
6. Open http://localhost:3000 in browser.

## What to test
- SQL Injection (login / register)
- Stored / Reflected / DOM XSS (comments, profile display)
- Broken access control (users page)
- SSRF (/fetch)
- Insecure file upload (/upload)
- Info leak (/config)

Remember to delete db/app.db and uploads/ when done.
