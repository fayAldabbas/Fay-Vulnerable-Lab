-- simple users and comments table
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS comments;

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  password TEXT, -- stored in plain text intentionally (Cryptographic Failures)
  role TEXT
);

CREATE TABLE comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  body TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

-- seed
INSERT INTO users (username, password, role) VALUES ('alice','alice123','user');
INSERT INTO users (username, password, role) VALUES ('bob','bob123','user');
INSERT INTO users (username, password, role) VALUES ('admin','admin123','admin');

INSERT INTO comments (user_id, body) VALUES (1, 'Hello from Alice');
INSERT INTO comments (user_id, body) VALUES (2, 'Bob was here');
